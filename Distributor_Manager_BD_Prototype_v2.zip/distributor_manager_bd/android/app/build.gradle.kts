plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.distributormanager.bd"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.distributormanager.bd"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}
