/* Firebase setup placeholder: replace values from Firebase Console before enabling cloud sync. */
window.FIREBASE_CONFIG = { apiKey: "PASTE_API_KEY_HERE", authDomain: "YOUR_PROJECT.firebaseapp.com", projectId: "YOUR_PROJECT_ID", appId: "PASTE_APP_ID_HERE" };
window.DMBD_ORG_ID = "YOUR_ORGANIZATION_ID";
