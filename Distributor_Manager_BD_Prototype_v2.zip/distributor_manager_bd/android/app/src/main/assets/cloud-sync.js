/* Firebase compat SDK adapter. Works only after firebase-config.js is configured and rules are deployed. */
(function(){
  const cfg=window.FIREBASE_CONFIG||{};
  const configured=!!(cfg.apiKey && cfg.apiKey!=='PASTE_API_KEY_HERE' && cfg.projectId && cfg.projectId!=='YOUR_PROJECT_ID' && window.DMBD_ORG_ID && window.DMBD_ORG_ID!=='YOUR_ORGANIZATION_ID');
  let app=null, auth=null, db=null, timer=null, lastCloudWrite=0;
  function ready(){return configured && window.firebase && firebase.apps && firebase.apps.length>=0;}
  function init(){if(!ready())return false;try{if(!firebase.apps.length)app=firebase.initializeApp(cfg);else app=firebase.app();auth=firebase.auth();db=firebase.firestore();db.enablePersistence({synchronizeTabs:true}).catch(()=>{});return true}catch(e){console.warn('Cloud init:',e);return false}}
  function path(){return db.collection('organizations').doc(window.DMBD_ORG_ID).collection('data').doc('main')}
  async function signIn(email,password){if(!init())throw new Error('Firebase কনফিগার করা নেই। README-এর ধাপ অনুসরণ করুন।');return auth.signInWithEmailAndPassword(email,password)}
  async function signOut(){if(auth) return auth.signOut()}
  async function push(state){if(!init()||!auth.currentUser)return false;const payload={state:state,updatedAt:firebase.firestore.FieldValue.serverTimestamp(),updatedBy:auth.currentUser.uid,schemaVersion:2};await path().set(payload);lastCloudWrite=Date.now();return true}
  async function pull(){if(!init()||!auth.currentUser)return null;const snap=await path().get();return snap.exists?snap.data().state:null}
  async function syncNow(){if(!init()||!auth||!auth.currentUser)return {status:'not-ready'};const remote=await pull();return {status:'ready',remote:remote}}
  function onAuth(cb){if(!init())return ()=>{};return auth.onAuthStateChanged(cb)}
  function status(){return {configured,authenticated:!!(auth&&auth.currentUser),email:auth&&auth.currentUser?auth.currentUser.email:null,orgId:window.DMBD_ORG_ID||null}}
  window.CloudSync={configured,init,signIn,signOut,push,pull,syncNow,onAuth,status};
})();
