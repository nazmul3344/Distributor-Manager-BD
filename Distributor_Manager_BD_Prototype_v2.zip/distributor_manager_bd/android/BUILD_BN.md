# Android APK build ও পরীক্ষা

1. Android Studio-তে এই `android` ফোল্ডারটি Open করুন।
2. Android SDK Platform 35 ইনস্টল করুন এবং Gradle Sync করুন।
3. ক্লাউড ব্যবহারের আগে `app/src/main/assets/firebase-config.js`-এ নিজের Firebase config দিন এবং Firestore rules/members সেটআপ সম্পন্ন করুন।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) চাপুন। Debug APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ থাকবে।
5. APK ইনস্টল করে পরীক্ষা করুন: কার্টন/পিস রূপান্তর, স্টক পর্যাপ্ততা, ডেলিভারি নিশ্চিতকরণ, একই অর্ডার দ্বিতীয়বার নিশ্চিত করা যায় কি না, অফলাইন লোকাল সংরক্ষণ, অনলাইন লগইন ও দুই ডিভাইসের সিঙ্ক।

এখনকার পরিবেশে Android SDK/Gradle উপস্থিত নেই; তাই APK build ও device test সম্পন্ন নয়।
