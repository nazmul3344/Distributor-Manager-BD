/*
  Firebase console > Project settings > Your apps > Web app থেকে config কপি করুন।
  এই ফাইলের কপি firebase-config.js নামে রাখুন। আসল config source archive-এ দেওয়ার আগে
  নিজের Firebase project-এ Authentication (Email/Password) ও Firestore চালু করুন।
*/
window.FIREBASE_CONFIG = {
  apiKey: "PASTE_API_KEY_HERE",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  appId: "PASTE_APP_ID_HERE"
};
window.DMBD_ORG_ID = "YOUR_ORGANIZATION_ID";
